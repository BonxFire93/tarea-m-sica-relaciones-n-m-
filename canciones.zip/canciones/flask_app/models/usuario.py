from flask_app.config.mysqlconnection import MYSQLConnection

class Usuario:
    def __init__(self, data):
        self.id = data['id']
        self.nombre = data['nombre']
        self.email = data['email']
        self.password = data['password']
        self.created_at = data['created_at']
        self.updated_at = data['updated_at']

    @classmethod
    def save(cls, data):
        query = "INSERT INTO usuarios (nombre, email, password, created_at, updated_at) VALUES (%(nombre)s, %(email)s, %(password)s, NOW(), NOW());"
        return MYSQLConnection('canciones').query_db(query, data)

    @classmethod
    def obtener_todos(cls):
        query = "SELECT * FROM usuarios;"
        results = MYSQLConnection('canciones').query_db(query)
        usuarios = []
        for usuario in results:
            usuarios.append(cls(usuario))
        return usuarios