from flask_app.config.mysqlconnection import MYSQLConnection

class Cancion:
    def __init__(self, data):
        self.id = data['id']
        self.titulo = data['titulo']
        self.artista = data['artista']
        self.album = data['album']
        self.genero = data['genero']
        self.created_at = data['created_at']
        self.updated_at = data['updated_at']

    @classmethod
    def save(cls, data):
        query = "INSERT INTO canciones (titulo, artista, album, genero, created_at, updated_at) VALUES (%(titulo)s, %(artista)s, %(album)s, %(genero)s, NOW(), NOW());"
        return MYSQLConnection('canciones').query_db(query, data)

    @classmethod
    def obtener_todas(cls):
        query = "SELECT * FROM canciones;"
        results = MYSQLConnection('canciones').query_db(query)
        canciones = []
        for cancion in results:
            canciones.append(cls(cancion))
        return canciones