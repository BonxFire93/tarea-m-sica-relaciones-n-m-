from flask import render_template, redirect, request, session, flash #type: ignore
from flask_app import app
import flask_app.models.usuario
from flask_app.models.cancion import Cancion

class Canciones:
    @app.route('/canciones')
    def cancuibes():
        if 'usuario_id' not in session:
            flash('Tienes que iniciar sesion para ver las canciones y artistas que estan en esta pagina causa :D')
            return redirect('/')
        canciones = Cancion.obtener_todas()
        return render_template('canciones.html', canciones=canciones)

class Crear_Cancion:
    @app.route('/crear_cancion', methods=['GET', 'POST'])
    def crear_cancion():
        if request.method == 'POST':
            data = {
                'titulo': request.form['titulo'],
                'artista': request.form['artista'],
                }
            return render_template('crear_cancion.html', data=data)