from flask import render_template, redirect, request, session, flash #type: ignore
from flask_app import app
import flask_app.models.usuario
from flask_app.models.cancion import Usuario

class Usuario:
    @app.route('/usuarios')
    def usuarios():
        if 'usuario_id' not in session:
            flash('hola')
            return render_template('usuarios.html')

class Crear_Usuario:
    @app.route('/crear_usuario', methods=['GET', 'POST'])
    def crear_usuario():
        usuario = None
        if request.method == 'POST':
            data = {
                'nombre': request.form['nombre'],
                'email': request.form['email'],
                'password': request.form['password'],
            }
        return render_template('crear_usuario.html', usuario=usuario)