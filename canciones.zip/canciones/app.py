from flask_app import app #Importamos la app de la carpeta flask_app
import flask_app.controllers #Importamos los módulos de estudiantes y cursos
from flask_app.controllers import canciones #Importamos los módulos de estudiantes y cursos

if __name__=="__main__": #Ejecutamos la aplicación
    app.run(debug=True)